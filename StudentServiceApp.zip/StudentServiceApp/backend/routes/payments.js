// routes/payments.js
const express = require('express');
const pool = require('../db');
const auth = require('../middleware/auth');
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);

const router = express.Router();

// Process payment
router.post('/', auth, async (req, res) => {
  const { request_id, amount, payment_method } = req.body;

  try {
    // Process Stripe payment
    const paymentIntent = await stripe.paymentIntents.create({
      amount: amount * 100, // Convert to cents
      currency: 'usd',
      payment_method,
      confirm: true,
    });

    // Save payment record in the database
    const newPayment = await pool.query(
      'INSERT INTO payments (request_id, amount, payment_method, transaction_id) VALUES ($1, $2, $3, $4) RETURNING *',
      [request_id, amount, payment_method, paymentIntent.id]
    );

    res.status(201).json(newPayment.rows[0]);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server error');
  }
});

module.exports = router;