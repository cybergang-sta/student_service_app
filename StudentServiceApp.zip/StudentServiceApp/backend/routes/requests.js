// routes/requests.js
const express = require('express');
const pool = require('../db');
const auth = require('../middleware/auth');

const router = express.Router();

// Submit a new request
router.post('/', auth, async (req, res) => {
  const { type, details, lecturer_id } = req.body;
  const student_id = req.user.id;

  try {
    const newRequest = await pool.query(
      'INSERT INTO requests (student_id, type, details, lecturer_id) VALUES ($1, $2, $3, $4) RETURNING *',
      [student_id, type, details, lecturer_id]
    );

    res.status(201).json(newRequest.rows[0]);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server error');
  }
});

// Get all requests for a student
router.get('/', auth, async (req, res) => {
  const student_id = req.user.id;

  try {
    const requests = await pool.query('SELECT * FROM requests WHERE student_id = $1', [student_id]);
    res.json(requests.rows);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server error');
  }
});

module.exports = router;