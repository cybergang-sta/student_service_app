// routes/documents.js
const express = require('express');
const pool = require('../db');
const auth = require('../middleware/auth');
const { uploadFile, getFileUrl } = require('../utils/s3'); // AWS S3 utility functions

const router = express.Router();

// Upload a document
router.post('/', auth, async (req, res) => {
  const { request_id, file } = req.body;

  try {
    const fileUrl = await uploadFile(file); // Upload file to S3
    const newDocument = await pool.query(
      'INSERT INTO documents (request_id, file_url) VALUES ($1, $2) RETURNING *',
      [request_id, fileUrl]
    );

    res.status(201).json(newDocument.rows[0]);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server error');
  }
});

// Download a document
router.get('/:request_id', auth, async (req, res) => {
  const { request_id } = req.params;

  try {
    const document = await pool.query('SELECT * FROM documents WHERE request_id = $1', [request_id]);

    if (document.rows.length === 0) {
      return res.status(404).json({ message: 'Document not found' });
    }

    const fileUrl = await getFileUrl(document.rows[0].file_url); // Get file URL from S3
    res.json({ fileUrl });
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server error');
  }
});

module.exports = router;