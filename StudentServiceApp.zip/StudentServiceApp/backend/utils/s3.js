// utils/s3.js
const { S3Client, PutObjectCommand } = require('@aws-sdk/client-s3');
const { getSignedUrl } = require('@aws-sdk/s3-request-presigner');

// Initialize the S3 client
const s3Client = new S3Client({
  region: process.env.AWS_REGION || 'us-east-1', // Default to 'us-east-1' if not provided
  credentials: {
    accessKeyId: process.env.AWS_ACCESS_KEY_ID,
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
  },
});

// Upload a file to S3
const uploadFile = async (file) => {
  const params = {
    Bucket: process.env.AWS_BUCKET_NAME,
    Key: file.filename, // Use the file's name as the S3 object key
    Body: file.buffer, // Use the file buffer (assuming `file` is a Multer file object)
    ContentType: file.mimetype, // Set the content type
  };

  try {
    const command = new PutObjectCommand(params);
    await s3Client.send(command);
    return `https://${process.env.AWS_BUCKET_NAME}.s3.amazonaws.com/${file.filename}`;
  } catch (err) {
    console.error('Error uploading file to S3:', err);
    throw err;
  }
};

// Generate a pre-signed URL for an S3 object
const getFileUrl = async (key) => {
  const params = {
    Bucket: process.env.AWS_BUCKET_NAME,
    Key: key,
    Expires: 60 * 60, // URL expires in 1 hour
  };

  try {
    const command = new GetObjectCommand(params);
    const url = await getSignedUrl(s3Client, command, { expiresIn: 3600 }); // 1 hour
    return url;
  } catch (err) {
    console.error('Error generating pre-signed URL:', err);
    throw err;
  }
};

module.exports = { uploadFile, getFileUrl };