# Student Services App - Backend

This is the backend for the Student Services App. It provides APIs for user authentication, requests, payments, and document management.

## Setup

1. Install dependencies:
   ```bash
   npm install