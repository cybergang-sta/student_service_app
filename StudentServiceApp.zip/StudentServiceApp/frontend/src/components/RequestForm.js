import React, { useState } from 'react';
import { Form, Button, Alert } from 'react-bootstrap';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const RequestForm = () => {
  const [type, setType] = useState('transcript');
  const [details, setDetails] = useState('');
  const [lecturerId, setLecturerId] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const token = localStorage.getItem('token');
      await axios.post(
        'http://localhost:5000/api/requests',
        { type, details, lecturer_id: lecturerId },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      navigate('/dashboard');
    } catch (err) {
      setError('Failed to submit request');
    }
  };

  return (
    <div className="container mt-5">
      <h2>Submit Request</h2>
      {error && <Alert variant="danger">{error}</Alert>}
      <Form onSubmit={handleSubmit}>
        <Form.Group className="mb-3">
          <Form.Label>Request Type</Form.Label>
          <Form.Select value={type} onChange={(e) => setType(e.target.value)}>
            <option value="transcript">Transcript</option>
            <option value="recommendation">Recommendation Letter</option>
            <option value="testimonial">Testimonial</option>
            <option value="english_proficiency">English Proficiency Letter</option>
          </Form.Select>
        </Form.Group>
        <Form.Group className="mb-3">
          <Form.Label>Details</Form.Label>
          <Form.Control
            as="textarea"
            rows={3}
            placeholder="Enter details"
            value={details}
            onChange={(e) => setDetails(e.target.value)}
            required
          />
        </Form.Group>
        <Form.Group className="mb-3">
          <Form.Label>Lecturer ID (for recommendation letters)</Form.Label>
          <Form.Control
            type="text"
            placeholder="Enter lecturer ID"
            value={lecturerId}
            onChange={(e) => setLecturerId(e.target.value)}
          />
        </Form.Group>
        <Button variant="primary" type="submit">Submit</Button>
      </Form>
    </div>
  );
};

export default RequestForm;