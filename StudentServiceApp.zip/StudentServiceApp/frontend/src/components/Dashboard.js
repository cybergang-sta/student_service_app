import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Button, Card, Container } from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';

const Dashboard = () => {
  const [requests, setRequests] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchRequests = async () => {
      const token = localStorage.getItem('token');
      const res = await axios.get('http://localhost:5000/api/requests', {
        headers: { Authorization: `Bearer ${token}` },
      });
      setRequests(res.data);
    };
    fetchRequests();
  }, []);

  return (
    <Container className="mt-5">
      <h2>Dashboard</h2>
      <Button onClick={() => navigate('/request')} className="mb-3 me-2">
        New Request
      </Button>
      <Button onClick={() => navigate('/documents')} className="mb-3">
        My Documents
      </Button>
      {requests.map((request) => (
        <Card key={request.request_id} className="mb-3">
          <Card.Body>
            <Card.Title>{request.type}</Card.Title>
            <Card.Text>{request.details}</Card.Text>
            <Button onClick={() => navigate(`/payment/${request.request_id}`)}>
              Make Payment
            </Button>
          </Card.Body>
        </Card>
      ))}
    </Container>
  );
};

export default Dashboard;