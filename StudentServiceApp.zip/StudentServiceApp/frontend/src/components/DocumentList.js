import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Button, Card, Container } from 'react-bootstrap';

const DocumentList = () => {
  const [documents, setDocuments] = useState([]);

  useEffect(() => {
    const fetchDocuments = async () => {
      const token = localStorage.getItem('token');
      const res = await axios.get('http://localhost:5000/api/documents', {
        headers: { Authorization: `Bearer ${token}` },
      });
      setDocuments(res.data);
    };
    fetchDocuments();
  }, []);

  const handleDownload = (fileUrl) => {
    window.open(fileUrl, '_blank');
  };

  return (
    <Container className="mt-5">
      <h2>My Documents</h2>
      {documents.map((document) => (
        <Card key={document.document_id} className="mb-3">
          <Card.Body>
            <Card.Title>Document for Request #{document.request_id}</Card.Title>
            <Button onClick={() => handleDownload(document.fileUrl)}>Download</Button>
          </Card.Body>
        </Card>
      ))}
    </Container>
  );
};

export default DocumentList;