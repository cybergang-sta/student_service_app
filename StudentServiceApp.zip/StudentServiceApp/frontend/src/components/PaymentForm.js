import React, { useState } from 'react';
import { Form, Button, Alert } from 'react-bootstrap';
import axios from 'axios';
import { useNavigate, useParams } from 'react-router-dom';

const PaymentForm = () => {
  const { requestId } = useParams();
  const [amount, setAmount] = useState(0);
  const [paymentMethod, setPaymentMethod] = useState('card');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const token = localStorage.getItem('token');
      await axios.post(
        'http://localhost:5000/api/payments',
        { request_id: requestId, amount, payment_method: paymentMethod },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      navigate('/dashboard');
    } catch (err) {
      setError('Payment failed');
    }
  };

  return (
    <div className="container mt-5">
      <h2>Make Payment</h2>
      {error && <Alert variant="danger">{error}</Alert>}
      <Form onSubmit={handleSubmit}>
        <Form.Group className="mb-3">
          <Form.Label>Amount</Form.Label>
          <Form.Control
            type="number"
            placeholder="Enter amount"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            required
          />
        </Form.Group>
        <Form.Group className="mb-3">
          <Form.Label>Payment Method</Form.Label>
          <Form.Select value={paymentMethod} onChange={(e) => setPaymentMethod(e.target.value)}>
            <option value="card">Credit/Debit Card</option>
            <option value="mobile_money">Mobile Money</option>
          </Form.Select>
        </Form.Group>
        <Button variant="primary" type="submit">Pay</Button>
      </Form>
    </div>
  );
};

export default PaymentForm;