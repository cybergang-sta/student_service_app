import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import NavbarComponent from './components/Navbar';
import Login from './components/Login';
import Register from './components/Register';
import Dashboard from './components/Dashboard';
import RequestForm from './components/RequestForm';
import PaymentForm from './components/PaymentForm';
import DocumentList from './components/DocumentList';
import './App.css';

const App = () => {
  return (
    <Router>
      <NavbarComponent />
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/request" element={<RequestForm />} />
        <Route path="/payment/:requestId" element={<PaymentForm />} />
        <Route path="/documents" element={<DocumentList />} />
        <Route path="/" element={<Login />} />
      </Routes>
    </Router>
  );
};

export default App;