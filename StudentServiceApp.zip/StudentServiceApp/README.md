# Student Services App - Frontend

This is the frontend for the Student Services App. It provides a user interface for students to register, log in, submit requests, make payments, and view/download documents.

## Setup

1. Install dependencies:
   ```bash
   npm install